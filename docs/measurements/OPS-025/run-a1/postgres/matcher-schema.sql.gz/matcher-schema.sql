--
-- PostgreSQL database dump
--

\restrict 4qbsYHX9wfXFpBYTJt7kwnRZxDSt3rQhBIww7tp3K9eYFz0wLJilcr086C9kHSC

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: matcher_migration
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO matcher_migration;

--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: matcher_migration
--

CREATE SCHEMA migration;


ALTER SCHEMA migration OWNER TO matcher_migration;

--
-- Name: storage_guard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA storage_guard;


ALTER SCHEMA storage_guard OWNER TO postgres;

--
-- Name: reject_unlogged(); Type: FUNCTION; Schema: storage_guard; Owner: postgres
--

CREATE FUNCTION storage_guard.reject_unlogged() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
  IF EXISTS (SELECT FROM pg_class WHERE relpersistence = 'u') THEN
    RAISE EXCEPTION 'unlogged relations are forbidden by DEC-006';
  END IF;
END;
$$;


ALTER FUNCTION storage_guard.reject_unlogged() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: matcher_assignment_requests; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_assignment_requests (
    assignment_key text NOT NULL,
    request_id text NOT NULL,
    request_body bytea NOT NULL,
    grant_body bytea NOT NULL,
    CONSTRAINT matcher_assignment_requests_request_id_check CHECK ((btrim(request_id) <> ''::text))
);


ALTER TABLE app.matcher_assignment_requests OWNER TO matcher_migration;

--
-- Name: matcher_assignments; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_assignments (
    assignment_key text NOT NULL,
    scope text NOT NULL,
    token bigint NOT NULL,
    grant_body bytea NOT NULL,
    active boolean NOT NULL,
    CONSTRAINT matcher_assignments_scope_check CHECK ((btrim(scope) <> ''::text)),
    CONSTRAINT matcher_assignments_token_check CHECK ((token > 0))
);


ALTER TABLE app.matcher_assignments OWNER TO matcher_migration;

--
-- Name: matcher_checkpoints; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_checkpoints (
    projection_id text NOT NULL,
    topic text,
    partition integer,
    journal_c numeric(20,0) DEFAULT 0 NOT NULL,
    next_offset bigint DEFAULT 0 NOT NULL,
    snapshot_id text,
    CONSTRAINT matcher_checkpoints_journal_c_check CHECK (((journal_c >= (0)::numeric) AND (journal_c <= '18446744073709551615'::numeric))),
    CONSTRAINT matcher_checkpoints_next_offset_check CHECK ((next_offset >= 0)),
    CONSTRAINT matcher_checkpoints_partition_check CHECK ((partition >= 0)),
    CONSTRAINT matcher_checkpoints_projection_id_check CHECK ((btrim(projection_id) <> ''::text)),
    CONSTRAINT matcher_checkpoints_topic_check CHECK ((btrim(topic) <> ''::text)),
    CONSTRAINT matcher_transport_presence CHECK ((((topic IS NULL) AND (partition IS NULL) AND (next_offset = 0)) OR ((topic IS NOT NULL) AND (partition IS NOT NULL))))
);


ALTER TABLE app.matcher_checkpoints OWNER TO matcher_migration;

--
-- Name: matcher_fence_gate; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_fence_gate (
    id integer NOT NULL,
    CONSTRAINT matcher_fence_gate_id_check CHECK ((id = 1))
);


ALTER TABLE app.matcher_fence_gate OWNER TO matcher_migration;

--
-- Name: matcher_price_candidates; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_price_candidates (
    scope text NOT NULL,
    work_key text NOT NULL,
    subscription_id text NOT NULL,
    candidate bytea NOT NULL,
    result bytea,
    CONSTRAINT matcher_price_candidates_candidate_check CHECK ((octet_length(candidate) > 0)),
    CONSTRAINT matcher_price_candidates_result_check CHECK ((octet_length(result) > 0)),
    CONSTRAINT matcher_price_candidates_subscription_id_check CHECK ((btrim(subscription_id) <> ''::text))
);


ALTER TABLE app.matcher_price_candidates OWNER TO matcher_migration;

--
-- Name: matcher_price_checkpoints; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_price_checkpoints (
    scope text NOT NULL,
    topic text NOT NULL,
    partition integer NOT NULL,
    next_offset bigint NOT NULL,
    CONSTRAINT matcher_price_checkpoints_next_offset_check CHECK ((next_offset >= 0)),
    CONSTRAINT matcher_price_checkpoints_partition_check CHECK ((partition >= 0)),
    CONSTRAINT matcher_price_checkpoints_scope_check CHECK ((btrim(scope) <> ''::text)),
    CONSTRAINT matcher_price_checkpoints_topic_check CHECK ((btrim(topic) <> ''::text))
);


ALTER TABLE app.matcher_price_checkpoints OWNER TO matcher_migration;

--
-- Name: matcher_price_work; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_price_work (
    scope text NOT NULL,
    work_key text NOT NULL,
    input bytea NOT NULL,
    total integer NOT NULL,
    completed integer DEFAULT 0 NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    superseded_by bytea,
    CONSTRAINT matcher_price_work_check CHECK (((completed >= 0) AND (completed <= total))),
    CONSTRAINT matcher_price_work_check1 CHECK (((state = 'superseded'::text) = (superseded_by IS NOT NULL))),
    CONSTRAINT matcher_price_work_check2 CHECK (((state <> 'completed'::text) OR (completed = total))),
    CONSTRAINT matcher_price_work_input_check CHECK ((octet_length(input) > 0)),
    CONSTRAINT matcher_price_work_scope_check CHECK ((btrim(scope) <> ''::text)),
    CONSTRAINT matcher_price_work_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'completed'::text, 'superseded'::text]))),
    CONSTRAINT matcher_price_work_total_check CHECK ((total >= 0)),
    CONSTRAINT matcher_price_work_work_key_check CHECK ((btrim(work_key) <> ''::text))
);


ALTER TABLE app.matcher_price_work OWNER TO matcher_migration;

--
-- Name: matcher_projection_grants; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_projection_grants (
    projection_id text NOT NULL,
    assignment_key text NOT NULL,
    grant_body bytea NOT NULL,
    CONSTRAINT matcher_projection_grants_projection_id_check CHECK ((btrim(projection_id) <> ''::text))
);


ALTER TABLE app.matcher_projection_grants OWNER TO matcher_migration;

--
-- Name: matcher_snapshot_generations; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_snapshot_generations (
    snapshot_id text NOT NULL,
    boundary_c numeric(20,0) NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    expires_text text NOT NULL,
    complete boolean DEFAULT false NOT NULL,
    row_count bigint DEFAULT 0 NOT NULL,
    CONSTRAINT matcher_snapshot_generations_boundary_c_check CHECK (((boundary_c >= (0)::numeric) AND (boundary_c <= '18446744073709551615'::numeric))),
    CONSTRAINT matcher_snapshot_generations_row_count_check CHECK ((row_count >= 0))
);


ALTER TABLE app.matcher_snapshot_generations OWNER TO matcher_migration;

--
-- Name: matcher_snapshot_rows; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_snapshot_rows (
    snapshot_id text NOT NULL,
    subscription_id text NOT NULL,
    body bytea NOT NULL,
    CONSTRAINT matcher_snapshot_rows_body_check CHECK ((octet_length(body) > 0))
);


ALTER TABLE app.matcher_snapshot_rows OWNER TO matcher_migration;

--
-- Name: matcher_subscriptions; Type: TABLE; Schema: app; Owner: matcher_migration
--

CREATE TABLE app.matcher_subscriptions (
    projection_id text NOT NULL,
    subscription_id text NOT NULL,
    version numeric(20,0) NOT NULL,
    body bytea,
    snapshot_body bytea,
    CONSTRAINT matcher_image_presence CHECK ((((body IS NOT NULL) AND (snapshot_body IS NULL)) OR ((body IS NULL) AND (snapshot_body IS NOT NULL) AND (octet_length(snapshot_body) > 0)))),
    CONSTRAINT matcher_subscriptions_body_check CHECK ((octet_length(body) > 0)),
    CONSTRAINT matcher_subscriptions_version_check CHECK (((version >= (1)::numeric) AND (version <= '18446744073709551615'::numeric)))
);


ALTER TABLE app.matcher_subscriptions OWNER TO matcher_migration;

--
-- Name: history; Type: TABLE; Schema: migration; Owner: matcher_migration
--

CREATE TABLE migration.history (
    version bigint NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT history_version_check CHECK ((version > 0))
);


ALTER TABLE migration.history OWNER TO matcher_migration;

--
-- Name: matcher_assignment_requests matcher_assignment_requests_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_assignment_requests
    ADD CONSTRAINT matcher_assignment_requests_pkey PRIMARY KEY (assignment_key, request_id);


--
-- Name: matcher_assignments matcher_assignments_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_assignments
    ADD CONSTRAINT matcher_assignments_pkey PRIMARY KEY (assignment_key);


--
-- Name: matcher_assignments matcher_assignments_scope_key; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_assignments
    ADD CONSTRAINT matcher_assignments_scope_key UNIQUE (scope);


--
-- Name: matcher_checkpoints matcher_checkpoints_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_checkpoints
    ADD CONSTRAINT matcher_checkpoints_pkey PRIMARY KEY (projection_id);


--
-- Name: matcher_fence_gate matcher_fence_gate_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_fence_gate
    ADD CONSTRAINT matcher_fence_gate_pkey PRIMARY KEY (id);


--
-- Name: matcher_price_candidates matcher_price_candidates_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_price_candidates
    ADD CONSTRAINT matcher_price_candidates_pkey PRIMARY KEY (scope, work_key, subscription_id);


--
-- Name: matcher_price_checkpoints matcher_price_checkpoints_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_price_checkpoints
    ADD CONSTRAINT matcher_price_checkpoints_pkey PRIMARY KEY (scope, topic, partition);


--
-- Name: matcher_price_work matcher_price_work_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_price_work
    ADD CONSTRAINT matcher_price_work_pkey PRIMARY KEY (scope, work_key);


--
-- Name: matcher_projection_grants matcher_projection_grants_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_projection_grants
    ADD CONSTRAINT matcher_projection_grants_pkey PRIMARY KEY (projection_id, assignment_key);


--
-- Name: matcher_snapshot_generations matcher_snapshot_generations_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_snapshot_generations
    ADD CONSTRAINT matcher_snapshot_generations_pkey PRIMARY KEY (snapshot_id);


--
-- Name: matcher_snapshot_rows matcher_snapshot_rows_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_snapshot_rows
    ADD CONSTRAINT matcher_snapshot_rows_pkey PRIMARY KEY (snapshot_id, subscription_id);


--
-- Name: matcher_subscriptions matcher_subscriptions_pkey; Type: CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_subscriptions
    ADD CONSTRAINT matcher_subscriptions_pkey PRIMARY KEY (projection_id, subscription_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: migration; Owner: matcher_migration
--

ALTER TABLE ONLY migration.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (version);


--
-- Name: matcher_price_pending; Type: INDEX; Schema: app; Owner: matcher_migration
--

CREATE INDEX matcher_price_pending ON app.matcher_price_work USING btree (scope, work_key) WHERE (state = 'pending'::text);


--
-- Name: matcher_assignment_requests matcher_assignment_requests_assignment_key_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_assignment_requests
    ADD CONSTRAINT matcher_assignment_requests_assignment_key_fkey FOREIGN KEY (assignment_key) REFERENCES app.matcher_assignments(assignment_key);


--
-- Name: matcher_checkpoints matcher_checkpoints_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_checkpoints
    ADD CONSTRAINT matcher_checkpoints_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES app.matcher_snapshot_generations(snapshot_id);


--
-- Name: matcher_price_candidates matcher_price_candidates_scope_work_key_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_price_candidates
    ADD CONSTRAINT matcher_price_candidates_scope_work_key_fkey FOREIGN KEY (scope, work_key) REFERENCES app.matcher_price_work(scope, work_key);


--
-- Name: matcher_projection_grants matcher_projection_grants_assignment_key_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_projection_grants
    ADD CONSTRAINT matcher_projection_grants_assignment_key_fkey FOREIGN KEY (assignment_key) REFERENCES app.matcher_assignments(assignment_key);


--
-- Name: matcher_snapshot_rows matcher_snapshot_rows_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_snapshot_rows
    ADD CONSTRAINT matcher_snapshot_rows_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES app.matcher_snapshot_generations(snapshot_id);


--
-- Name: matcher_subscriptions matcher_subscriptions_projection_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: matcher_migration
--

ALTER TABLE ONLY app.matcher_subscriptions
    ADD CONSTRAINT matcher_subscriptions_projection_id_fkey FOREIGN KEY (projection_id) REFERENCES app.matcher_checkpoints(projection_id);


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: matcher_migration
--

GRANT USAGE ON SCHEMA app TO matcher_runtime;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: FUNCTION reject_unlogged(); Type: ACL; Schema: storage_guard; Owner: postgres
--

REVOKE ALL ON FUNCTION storage_guard.reject_unlogged() FROM PUBLIC;


--
-- Name: TABLE matcher_assignment_requests; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_assignment_requests TO matcher_runtime;


--
-- Name: TABLE matcher_assignments; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_assignments TO matcher_runtime;


--
-- Name: COLUMN matcher_assignments.token; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(token) ON TABLE app.matcher_assignments TO matcher_runtime;


--
-- Name: COLUMN matcher_assignments.grant_body; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(grant_body) ON TABLE app.matcher_assignments TO matcher_runtime;


--
-- Name: COLUMN matcher_assignments.active; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(active) ON TABLE app.matcher_assignments TO matcher_runtime;


--
-- Name: TABLE matcher_checkpoints; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_checkpoints TO matcher_runtime;


--
-- Name: TABLE matcher_fence_gate; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_fence_gate TO matcher_runtime;


--
-- Name: COLUMN matcher_fence_gate.id; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(id) ON TABLE app.matcher_fence_gate TO matcher_runtime;


--
-- Name: TABLE matcher_price_candidates; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_price_candidates TO matcher_runtime;


--
-- Name: COLUMN matcher_price_candidates.result; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(result) ON TABLE app.matcher_price_candidates TO matcher_runtime;


--
-- Name: TABLE matcher_price_checkpoints; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_price_checkpoints TO matcher_runtime;


--
-- Name: COLUMN matcher_price_checkpoints.next_offset; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(next_offset) ON TABLE app.matcher_price_checkpoints TO matcher_runtime;


--
-- Name: TABLE matcher_price_work; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_price_work TO matcher_runtime;


--
-- Name: COLUMN matcher_price_work.completed; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(completed) ON TABLE app.matcher_price_work TO matcher_runtime;


--
-- Name: COLUMN matcher_price_work.state; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(state) ON TABLE app.matcher_price_work TO matcher_runtime;


--
-- Name: COLUMN matcher_price_work.superseded_by; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(superseded_by) ON TABLE app.matcher_price_work TO matcher_runtime;


--
-- Name: TABLE matcher_projection_grants; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_projection_grants TO matcher_runtime;


--
-- Name: COLUMN matcher_projection_grants.grant_body; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT UPDATE(grant_body) ON TABLE app.matcher_projection_grants TO matcher_runtime;


--
-- Name: TABLE matcher_snapshot_generations; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_snapshot_generations TO matcher_runtime;


--
-- Name: TABLE matcher_snapshot_rows; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_snapshot_rows TO matcher_runtime;


--
-- Name: TABLE matcher_subscriptions; Type: ACL; Schema: app; Owner: matcher_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.matcher_subscriptions TO matcher_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: app; Owner: matcher_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE matcher_migration IN SCHEMA app GRANT SELECT,USAGE ON SEQUENCES TO matcher_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: matcher_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE matcher_migration IN SCHEMA app GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO matcher_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: matcher_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE matcher_migration REVOKE ALL ON FUNCTIONS FROM PUBLIC;


--
-- Name: reject_unlogged; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER reject_unlogged ON ddl_command_end
   EXECUTE FUNCTION storage_guard.reject_unlogged();


ALTER EVENT TRIGGER reject_unlogged OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict 4qbsYHX9wfXFpBYTJt7kwnRZxDSt3rQhBIww7tp3K9eYFz0wLJilcr086C9kHSC

