--
-- PostgreSQL database dump
--

\restrict F8R0K6NZr3qLHEBBKMHRptVBQ3Zh6LTEI1pzILjJuVO4fCUacgDBQQ7aqcMNsfN

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: market_data_migration
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO market_data_migration;

--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: market_data_migration
--

CREATE SCHEMA migration;


ALTER SCHEMA migration OWNER TO market_data_migration;

--
-- Name: storage_guard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA storage_guard;


ALTER SCHEMA storage_guard OWNER TO postgres;

--
-- Name: reject_unlogged(); Type: FUNCTION; Schema: storage_guard; Owner: postgres
--

CREATE FUNCTION storage_guard.reject_unlogged() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
  IF EXISTS (SELECT FROM pg_class WHERE relpersistence = 'u') THEN
    RAISE EXCEPTION 'unlogged relations are forbidden by DEC-006';
  END IF;
END;
$$;


ALTER FUNCTION storage_guard.reject_unlogged() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: market_streams; Type: TABLE; Schema: app; Owner: market_data_migration
--

CREATE TABLE app.market_streams (
    pair text NOT NULL,
    generation bigint NOT NULL,
    sequence bigint DEFAULT 0 NOT NULL,
    state text NOT NULL,
    gap_detected boolean DEFAULT false NOT NULL,
    latest jsonb,
    CONSTRAINT market_streams_generation_check CHECK ((generation > 0)),
    CONSTRAINT market_streams_pair_check CHECK ((pair ~ '^[A-Z0-9]+$'::text)),
    CONSTRAINT market_streams_sequence_check CHECK ((sequence >= 0)),
    CONSTRAINT market_streams_state_check CHECK ((state = ANY (ARRAY['unconfirmed'::text, 'live'::text])))
);


ALTER TABLE app.market_streams OWNER TO market_data_migration;

--
-- Name: price_outbox; Type: TABLE; Schema: app; Owner: market_data_migration
--

CREATE TABLE app.price_outbox (
    "position" bigint NOT NULL,
    event_id text NOT NULL,
    pair text NOT NULL,
    data bytea NOT NULL,
    published boolean DEFAULT false NOT NULL,
    claim_token bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    CONSTRAINT price_outbox_claim_token_check CHECK ((claim_token >= 0)),
    CONSTRAINT price_outbox_event_id_check CHECK ((btrim(event_id) <> ''::text))
);


ALTER TABLE app.price_outbox OWNER TO market_data_migration;

--
-- Name: price_outbox_position_seq; Type: SEQUENCE; Schema: app; Owner: market_data_migration
--

ALTER TABLE app.price_outbox ALTER COLUMN "position" ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME app.price_outbox_position_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: history; Type: TABLE; Schema: migration; Owner: market_data_migration
--

CREATE TABLE migration.history (
    version bigint NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT history_version_check CHECK ((version > 0))
);


ALTER TABLE migration.history OWNER TO market_data_migration;

--
-- Name: market_streams market_streams_pkey; Type: CONSTRAINT; Schema: app; Owner: market_data_migration
--

ALTER TABLE ONLY app.market_streams
    ADD CONSTRAINT market_streams_pkey PRIMARY KEY (pair);


--
-- Name: price_outbox price_outbox_event_id_key; Type: CONSTRAINT; Schema: app; Owner: market_data_migration
--

ALTER TABLE ONLY app.price_outbox
    ADD CONSTRAINT price_outbox_event_id_key UNIQUE (event_id);


--
-- Name: price_outbox price_outbox_pkey; Type: CONSTRAINT; Schema: app; Owner: market_data_migration
--

ALTER TABLE ONLY app.price_outbox
    ADD CONSTRAINT price_outbox_pkey PRIMARY KEY ("position");


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: migration; Owner: market_data_migration
--

ALTER TABLE ONLY migration.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (version);


--
-- Name: price_outbox_pending; Type: INDEX; Schema: app; Owner: market_data_migration
--

CREATE INDEX price_outbox_pending ON app.price_outbox USING btree (pair, "position") WHERE (NOT published);


--
-- Name: price_outbox price_outbox_pair_fkey; Type: FK CONSTRAINT; Schema: app; Owner: market_data_migration
--

ALTER TABLE ONLY app.price_outbox
    ADD CONSTRAINT price_outbox_pair_fkey FOREIGN KEY (pair) REFERENCES app.market_streams(pair);


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: market_data_migration
--

GRANT USAGE ON SCHEMA app TO market_data_runtime;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: FUNCTION reject_unlogged(); Type: ACL; Schema: storage_guard; Owner: postgres
--

REVOKE ALL ON FUNCTION storage_guard.reject_unlogged() FROM PUBLIC;


--
-- Name: TABLE market_streams; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.market_streams TO market_data_runtime;


--
-- Name: TABLE price_outbox; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT SELECT,INSERT ON TABLE app.price_outbox TO market_data_runtime;


--
-- Name: COLUMN price_outbox.published; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT UPDATE(published) ON TABLE app.price_outbox TO market_data_runtime;


--
-- Name: COLUMN price_outbox.claim_token; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT UPDATE(claim_token) ON TABLE app.price_outbox TO market_data_runtime;


--
-- Name: COLUMN price_outbox.lease_until; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT UPDATE(lease_until) ON TABLE app.price_outbox TO market_data_runtime;


--
-- Name: SEQUENCE price_outbox_position_seq; Type: ACL; Schema: app; Owner: market_data_migration
--

GRANT SELECT,USAGE ON SEQUENCE app.price_outbox_position_seq TO market_data_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: app; Owner: market_data_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE market_data_migration IN SCHEMA app GRANT SELECT,USAGE ON SEQUENCES TO market_data_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: market_data_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE market_data_migration IN SCHEMA app GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO market_data_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: market_data_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE market_data_migration REVOKE ALL ON FUNCTIONS FROM PUBLIC;


--
-- Name: reject_unlogged; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER reject_unlogged ON ddl_command_end
   EXECUTE FUNCTION storage_guard.reject_unlogged();


ALTER EVENT TRIGGER reject_unlogged OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict F8R0K6NZr3qLHEBBKMHRptVBQ3Zh6LTEI1pzILjJuVO4fCUacgDBQQ7aqcMNsfN

