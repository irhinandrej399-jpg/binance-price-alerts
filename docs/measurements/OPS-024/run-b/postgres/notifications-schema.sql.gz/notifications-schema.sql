--
-- PostgreSQL database dump
--

\restrict G1ffuck9I1v2QVy4eRtGgPZztkG8r1D8SXeEPz1ojIlFMp5eFe0fBst3A6gMa4J

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: notifications_migration
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO notifications_migration;

--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: notifications_migration
--

CREATE SCHEMA migration;


ALTER SCHEMA migration OWNER TO notifications_migration;

--
-- Name: storage_guard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA storage_guard;


ALTER SCHEMA storage_guard OWNER TO postgres;

--
-- Name: reject_unlogged(); Type: FUNCTION; Schema: storage_guard; Owner: postgres
--

CREATE FUNCTION storage_guard.reject_unlogged() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
  IF EXISTS (SELECT FROM pg_class WHERE relpersistence = 'u') THEN
    RAISE EXCEPTION 'unlogged relations are forbidden by DEC-006';
  END IF;
END;
$$;


ALTER FUNCTION storage_guard.reject_unlogged() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: bot_limits; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.bot_limits (
    bot_id text NOT NULL,
    interval_us bigint NOT NULL,
    next_allowed_at timestamp with time zone NOT NULL,
    CONSTRAINT bot_limits_bot_id_check CHECK ((bot_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT bot_limits_interval_us_check CHECK ((interval_us > 0))
);


ALTER TABLE app.bot_limits OWNER TO notifications_migration;

--
-- Name: chat_limits; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.chat_limits (
    bot_id text NOT NULL,
    chat_id bigint NOT NULL,
    interval_us bigint NOT NULL,
    next_allowed_at timestamp with time zone NOT NULL,
    CONSTRAINT chat_limits_bot_id_check CHECK ((bot_id ~ '^[1-9][0-9]*$'::text)),
    CONSTRAINT chat_limits_chat_id_check CHECK ((chat_id <> 0)),
    CONSTRAINT chat_limits_interval_us_check CHECK ((interval_us > 0))
);


ALTER TABLE app.chat_limits OWNER TO notifications_migration;

--
-- Name: delivery_attempts; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_attempts (
    attempt_id text NOT NULL,
    claim_id text NOT NULL,
    trigger_id text NOT NULL,
    fence bigint NOT NULL,
    registered_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_attempts_attempt_id_check CHECK ((btrim(attempt_id) <> ''::text))
);


ALTER TABLE app.delivery_attempts OWNER TO notifications_migration;

--
-- Name: delivery_block_parks; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_block_parks (
    claim_id text NOT NULL,
    reason text NOT NULL,
    binding_version bigint NOT NULL,
    CONSTRAINT delivery_block_parks_binding_version_check CHECK ((binding_version >= 0)),
    CONSTRAINT delivery_block_parks_reason_check CHECK ((reason = ANY (ARRAY['channel_unavailable'::text, 'permanent_failure'::text, 'attempts_exhausted'::text])))
);


ALTER TABLE app.delivery_block_parks OWNER TO notifications_migration;

--
-- Name: delivery_blocked_reports; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_blocked_reports (
    attempt_id text NOT NULL,
    pending boolean DEFAULT true NOT NULL
);


ALTER TABLE app.delivery_blocked_reports OWNER TO notifications_migration;

--
-- Name: delivery_blocks; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_blocks (
    attempt_id text NOT NULL,
    reason text NOT NULL,
    binding_version bigint NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_blocks_binding_version_check CHECK ((binding_version >= 0)),
    CONSTRAINT delivery_blocks_reason_check CHECK ((reason = ANY (ARRAY['channel_unavailable'::text, 'permanent_failure'::text, 'attempts_exhausted'::text])))
);


ALTER TABLE app.delivery_blocks OWNER TO notifications_migration;

--
-- Name: delivery_checkpoints; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_checkpoints (
    topic text NOT NULL,
    partition integer NOT NULL,
    next_offset bigint DEFAULT 0 NOT NULL,
    CONSTRAINT delivery_checkpoints_next_offset_check CHECK ((next_offset >= 0)),
    CONSTRAINT delivery_checkpoints_partition_check CHECK ((partition >= 0)),
    CONSTRAINT delivery_checkpoints_topic_check CHECK ((btrim(topic) <> ''::text))
);


ALTER TABLE app.delivery_checkpoints OWNER TO notifications_migration;

--
-- Name: delivery_claims; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_claims (
    claim_id text NOT NULL,
    trigger_id text NOT NULL,
    fence bigint NOT NULL,
    claimed_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    status text NOT NULL,
    CONSTRAINT delivery_claims_check CHECK ((expires_at > claimed_at)),
    CONSTRAINT delivery_claims_claim_id_check CHECK ((btrim(claim_id) <> ''::text)),
    CONSTRAINT delivery_claims_fence_check CHECK ((fence > 0)),
    CONSTRAINT delivery_claims_status_check CHECK ((status = ANY (ARRAY['claimed'::text, 'expired'::text, 'released'::text, 'completed'::text])))
);


ALTER TABLE app.delivery_claims OWNER TO notifications_migration;

--
-- Name: delivery_jobs; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_jobs (
    trigger_id text NOT NULL,
    subscription_id text NOT NULL,
    user_id text NOT NULL,
    event_id text NOT NULL,
    body bytea NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    lease_fence bigint DEFAULT 0 NOT NULL,
    lease_id text,
    lease_expires_at timestamp with time zone,
    next_attempt_at timestamp with time zone DEFAULT '-infinity'::timestamp with time zone NOT NULL,
    blocked_reason text,
    blocked_binding_version bigint,
    next_check_at timestamp with time zone,
    CONSTRAINT blocked_metadata_shape CHECK (((blocked_reason IS NULL) = (blocked_binding_version IS NULL))),
    CONSTRAINT delivery_jobs_blocked_binding_version_check CHECK ((blocked_binding_version >= 0)),
    CONSTRAINT delivery_jobs_blocked_reason_check CHECK ((blocked_reason = ANY (ARRAY['channel_unavailable'::text, 'permanent_failure'::text, 'attempts_exhausted'::text]))),
    CONSTRAINT delivery_jobs_body_check CHECK ((octet_length(body) > 0)),
    CONSTRAINT delivery_jobs_event_id_check CHECK ((btrim(event_id) <> ''::text)),
    CONSTRAINT delivery_jobs_lease_fence_check CHECK ((lease_fence >= 0)),
    CONSTRAINT delivery_jobs_state_check CHECK ((btrim(state) <> ''::text)),
    CONSTRAINT delivery_jobs_subscription_id_check CHECK ((btrim(subscription_id) <> ''::text)),
    CONSTRAINT delivery_jobs_trigger_id_check CHECK ((btrim(trigger_id) <> ''::text)),
    CONSTRAINT delivery_jobs_user_id_check CHECK ((btrim(user_id) <> ''::text)),
    CONSTRAINT job_lease_shape CHECK ((((lease_id IS NULL) AND (lease_expires_at IS NULL)) OR ((lease_id IS NOT NULL) AND (btrim(lease_id) <> ''::text) AND (lease_expires_at IS NOT NULL) AND (lease_fence > 0))))
);


ALTER TABLE app.delivery_jobs OWNER TO notifications_migration;

--
-- Name: delivery_retryable_reports; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_retryable_reports (
    attempt_id text NOT NULL,
    pending boolean DEFAULT true NOT NULL
);


ALTER TABLE app.delivery_retryable_reports OWNER TO notifications_migration;

--
-- Name: delivery_retryables; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_retryables (
    attempt_id text NOT NULL,
    kind text NOT NULL,
    retry_after_seconds bigint NOT NULL,
    binding_version bigint NOT NULL,
    failures bigint NOT NULL,
    exhausted boolean NOT NULL,
    next_attempt_at timestamp with time zone,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_retryables_binding_version_check CHECK ((binding_version >= 0)),
    CONSTRAINT delivery_retryables_check CHECK (((exhausted AND (next_attempt_at IS NULL)) OR ((NOT exhausted) AND (next_attempt_at IS NOT NULL) AND isfinite(next_attempt_at)))),
    CONSTRAINT delivery_retryables_failures_check CHECK (((failures >= 1) AND (failures <= '4294967295'::bigint))),
    CONSTRAINT delivery_retryables_kind_check CHECK ((kind = ANY (ARRAY['rate_limited'::text, 'server'::text]))),
    CONSTRAINT delivery_retryables_retry_after_seconds_check CHECK ((retry_after_seconds >= 0))
);


ALTER TABLE app.delivery_retryables OWNER TO notifications_migration;

--
-- Name: delivery_success_reports; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_success_reports (
    attempt_id text NOT NULL,
    pending boolean DEFAULT true NOT NULL
);


ALTER TABLE app.delivery_success_reports OWNER TO notifications_migration;

--
-- Name: delivery_successes; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_successes (
    attempt_id text NOT NULL,
    message_id bigint NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_successes_message_id_check CHECK ((message_id > 0))
);


ALTER TABLE app.delivery_successes OWNER TO notifications_migration;

--
-- Name: delivery_uncertain_reports; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_uncertain_reports (
    attempt_id text NOT NULL,
    pending boolean DEFAULT true NOT NULL
);


ALTER TABLE app.delivery_uncertain_reports OWNER TO notifications_migration;

--
-- Name: delivery_uncertainties; Type: TABLE; Schema: app; Owner: notifications_migration
--

CREATE TABLE app.delivery_uncertainties (
    attempt_id text NOT NULL,
    next_attempt_at timestamp with time zone NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_uncertainties_next_attempt_at_check CHECK (isfinite(next_attempt_at))
);


ALTER TABLE app.delivery_uncertainties OWNER TO notifications_migration;

--
-- Name: history; Type: TABLE; Schema: migration; Owner: notifications_migration
--

CREATE TABLE migration.history (
    version bigint NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT history_version_check CHECK ((version > 0))
);


ALTER TABLE migration.history OWNER TO notifications_migration;

--
-- Name: bot_limits bot_limits_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.bot_limits
    ADD CONSTRAINT bot_limits_pkey PRIMARY KEY (bot_id);


--
-- Name: chat_limits chat_limits_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.chat_limits
    ADD CONSTRAINT chat_limits_pkey PRIMARY KEY (bot_id, chat_id);


--
-- Name: delivery_attempts delivery_attempts_claim_id_key; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_attempts
    ADD CONSTRAINT delivery_attempts_claim_id_key UNIQUE (claim_id);


--
-- Name: delivery_attempts delivery_attempts_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_attempts
    ADD CONSTRAINT delivery_attempts_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_block_parks delivery_block_parks_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_block_parks
    ADD CONSTRAINT delivery_block_parks_pkey PRIMARY KEY (claim_id);


--
-- Name: delivery_blocked_reports delivery_blocked_reports_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_blocked_reports
    ADD CONSTRAINT delivery_blocked_reports_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_blocks delivery_blocks_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_blocks
    ADD CONSTRAINT delivery_blocks_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_checkpoints delivery_checkpoints_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_checkpoints
    ADD CONSTRAINT delivery_checkpoints_pkey PRIMARY KEY (topic, partition);


--
-- Name: delivery_claims delivery_claim_identity; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_claims
    ADD CONSTRAINT delivery_claim_identity UNIQUE (claim_id, trigger_id, fence);


--
-- Name: delivery_claims delivery_claims_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_claims
    ADD CONSTRAINT delivery_claims_pkey PRIMARY KEY (claim_id);


--
-- Name: delivery_claims delivery_claims_trigger_id_fence_key; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_claims
    ADD CONSTRAINT delivery_claims_trigger_id_fence_key UNIQUE (trigger_id, fence);


--
-- Name: delivery_jobs delivery_jobs_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_jobs
    ADD CONSTRAINT delivery_jobs_pkey PRIMARY KEY (trigger_id);


--
-- Name: delivery_retryable_reports delivery_retryable_reports_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_retryable_reports
    ADD CONSTRAINT delivery_retryable_reports_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_retryables delivery_retryables_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_retryables
    ADD CONSTRAINT delivery_retryables_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_success_reports delivery_success_reports_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_success_reports
    ADD CONSTRAINT delivery_success_reports_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_successes delivery_successes_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_successes
    ADD CONSTRAINT delivery_successes_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_uncertain_reports delivery_uncertain_reports_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_uncertain_reports
    ADD CONSTRAINT delivery_uncertain_reports_pkey PRIMARY KEY (attempt_id);


--
-- Name: delivery_uncertainties delivery_uncertainties_pkey; Type: CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_uncertainties
    ADD CONSTRAINT delivery_uncertainties_pkey PRIMARY KEY (attempt_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: migration; Owner: notifications_migration
--

ALTER TABLE ONLY migration.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (version);


--
-- Name: delivery_attempts_workflow; Type: INDEX; Schema: app; Owner: notifications_migration
--

CREATE INDEX delivery_attempts_workflow ON app.delivery_attempts USING btree (trigger_id);


--
-- Name: delivery_channel_checks; Type: INDEX; Schema: app; Owner: notifications_migration
--

CREATE INDEX delivery_channel_checks ON app.delivery_jobs USING btree (next_check_at, trigger_id) WHERE ((next_check_at IS NOT NULL) AND (state = 'blocked'::text));


--
-- Name: delivery_attempts delivery_attempts_claim_id_trigger_id_fence_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_attempts
    ADD CONSTRAINT delivery_attempts_claim_id_trigger_id_fence_fkey FOREIGN KEY (claim_id, trigger_id, fence) REFERENCES app.delivery_claims(claim_id, trigger_id, fence);


--
-- Name: delivery_block_parks delivery_block_parks_claim_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_block_parks
    ADD CONSTRAINT delivery_block_parks_claim_id_fkey FOREIGN KEY (claim_id) REFERENCES app.delivery_claims(claim_id);


--
-- Name: delivery_blocked_reports delivery_blocked_reports_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_blocked_reports
    ADD CONSTRAINT delivery_blocked_reports_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_blocks(attempt_id);


--
-- Name: delivery_blocks delivery_blocks_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_blocks
    ADD CONSTRAINT delivery_blocks_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_attempts(attempt_id);


--
-- Name: delivery_claims delivery_claims_trigger_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_claims
    ADD CONSTRAINT delivery_claims_trigger_id_fkey FOREIGN KEY (trigger_id) REFERENCES app.delivery_jobs(trigger_id);


--
-- Name: delivery_retryable_reports delivery_retryable_reports_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_retryable_reports
    ADD CONSTRAINT delivery_retryable_reports_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_retryables(attempt_id);


--
-- Name: delivery_retryables delivery_retryables_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_retryables
    ADD CONSTRAINT delivery_retryables_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_attempts(attempt_id);


--
-- Name: delivery_success_reports delivery_success_reports_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_success_reports
    ADD CONSTRAINT delivery_success_reports_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_successes(attempt_id);


--
-- Name: delivery_successes delivery_successes_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_successes
    ADD CONSTRAINT delivery_successes_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_attempts(attempt_id);


--
-- Name: delivery_uncertain_reports delivery_uncertain_reports_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_uncertain_reports
    ADD CONSTRAINT delivery_uncertain_reports_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_uncertainties(attempt_id);


--
-- Name: delivery_uncertainties delivery_uncertainties_attempt_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: notifications_migration
--

ALTER TABLE ONLY app.delivery_uncertainties
    ADD CONSTRAINT delivery_uncertainties_attempt_id_fkey FOREIGN KEY (attempt_id) REFERENCES app.delivery_attempts(attempt_id);


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: notifications_migration
--

GRANT USAGE ON SCHEMA app TO notifications_runtime;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: FUNCTION reject_unlogged(); Type: ACL; Schema: storage_guard; Owner: postgres
--

REVOKE ALL ON FUNCTION storage_guard.reject_unlogged() FROM PUBLIC;


--
-- Name: TABLE bot_limits; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.bot_limits TO notifications_runtime;


--
-- Name: TABLE chat_limits; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.chat_limits TO notifications_runtime;


--
-- Name: TABLE delivery_attempts; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_attempts TO notifications_runtime;


--
-- Name: TABLE delivery_block_parks; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_block_parks TO notifications_runtime;


--
-- Name: TABLE delivery_blocked_reports; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_blocked_reports TO notifications_runtime;


--
-- Name: TABLE delivery_blocks; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_blocks TO notifications_runtime;


--
-- Name: TABLE delivery_checkpoints; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_checkpoints TO notifications_runtime;


--
-- Name: TABLE delivery_claims; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_claims TO notifications_runtime;


--
-- Name: TABLE delivery_jobs; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_jobs TO notifications_runtime;


--
-- Name: TABLE delivery_retryable_reports; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,UPDATE ON TABLE app.delivery_retryable_reports TO notifications_runtime;


--
-- Name: TABLE delivery_retryables; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT ON TABLE app.delivery_retryables TO notifications_runtime;


--
-- Name: TABLE delivery_success_reports; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_success_reports TO notifications_runtime;


--
-- Name: TABLE delivery_successes; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_successes TO notifications_runtime;


--
-- Name: TABLE delivery_uncertain_reports; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_uncertain_reports TO notifications_runtime;


--
-- Name: TABLE delivery_uncertainties; Type: ACL; Schema: app; Owner: notifications_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.delivery_uncertainties TO notifications_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: app; Owner: notifications_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE notifications_migration IN SCHEMA app GRANT SELECT,USAGE ON SEQUENCES TO notifications_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: notifications_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE notifications_migration IN SCHEMA app GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO notifications_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: notifications_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE notifications_migration REVOKE ALL ON FUNCTIONS FROM PUBLIC;


--
-- Name: reject_unlogged; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER reject_unlogged ON ddl_command_end
   EXECUTE FUNCTION storage_guard.reject_unlogged();


ALTER EVENT TRIGGER reject_unlogged OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict G1ffuck9I1v2QVy4eRtGgPZztkG8r1D8SXeEPz1ojIlFMp5eFe0fBst3A6gMa4J

