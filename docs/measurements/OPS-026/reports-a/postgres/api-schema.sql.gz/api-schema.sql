--
-- PostgreSQL database dump
--

\restrict obG9AAexgpeo73u1ae1Q8BUTwWaPuC34EWKmGHxyyJUrhMtOigLFqyX34xHLLd6

-- Dumped from database version 18.6 (Debian 18.6-1.pgdg12+2)
-- Dumped by pg_dump version 18.6 (Debian 18.6-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: app; Type: SCHEMA; Schema: -; Owner: api_migration
--

CREATE SCHEMA app;


ALTER SCHEMA app OWNER TO api_migration;

--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: api_migration
--

CREATE SCHEMA migration;


ALTER SCHEMA migration OWNER TO api_migration;

--
-- Name: storage_guard; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA storage_guard;


ALTER SCHEMA storage_guard OWNER TO postgres;

--
-- Name: reject_unlogged(); Type: FUNCTION; Schema: storage_guard; Owner: postgres
--

CREATE FUNCTION storage_guard.reject_unlogged() RETURNS event_trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'pg_catalog'
    AS $$
BEGIN
  IF EXISTS (SELECT FROM pg_class WHERE relpersistence = 'u') THEN
    RAISE EXCEPTION 'unlogged relations are forbidden by DEC-006';
  END IF;
END;
$$;


ALTER FUNCTION storage_guard.reject_unlogged() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: api_journal; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.api_journal (
    "position" bigint NOT NULL,
    transaction_end bigint NOT NULL,
    event_id text NOT NULL,
    body bytea NOT NULL,
    CONSTRAINT api_journal_body_check CHECK ((octet_length(body) > 0)),
    CONSTRAINT api_journal_check CHECK (("position" <= transaction_end)),
    CONSTRAINT api_journal_event_id_check CHECK ((btrim(event_id) <> ''::text)),
    CONSTRAINT api_journal_position_check CHECK (("position" > 0))
);


ALTER TABLE app.api_journal OWNER TO api_migration;

--
-- Name: api_journal_batches; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.api_journal_batches (
    transaction_id xid8 NOT NULL,
    transaction_end bigint NOT NULL,
    CONSTRAINT api_journal_batches_transaction_end_check CHECK ((transaction_end > 0))
);


ALTER TABLE app.api_journal_batches OWNER TO api_migration;

--
-- Name: api_journal_counter; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.api_journal_counter (
    singleton boolean DEFAULT true NOT NULL,
    "position" bigint NOT NULL,
    CONSTRAINT api_journal_counter_position_check CHECK (("position" >= 0)),
    CONSTRAINT api_journal_counter_singleton_check CHECK (singleton)
);


ALTER TABLE app.api_journal_counter OWNER TO api_migration;

--
-- Name: delivery_admissions; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.delivery_admissions (
    subscription_id uuid NOT NULL,
    request_id text NOT NULL,
    workflow_id text NOT NULL,
    attempt_id text,
    fence bigint,
    expires_at timestamp with time zone,
    chat_id bigint,
    binding_version bigint,
    response bytea NOT NULL,
    CONSTRAINT delivery_admissions_check CHECK ((((attempt_id IS NULL) AND (fence IS NULL) AND (expires_at IS NULL) AND (chat_id IS NULL) AND (binding_version IS NULL)) OR ((attempt_id IS NOT NULL) AND (btrim(attempt_id) <> ''::text) AND (fence IS NOT NULL) AND (fence > 0) AND (expires_at IS NOT NULL) AND (chat_id IS NOT NULL) AND (chat_id > 0) AND (binding_version IS NOT NULL) AND (binding_version > 0)))),
    CONSTRAINT delivery_admissions_request_id_check CHECK (((length(request_id) >= 1) AND (length(request_id) <= 200))),
    CONSTRAINT delivery_admissions_response_check CHECK ((octet_length(response) > 0)),
    CONSTRAINT delivery_admissions_workflow_id_check CHECK ((btrim(workflow_id) <> ''::text))
);


ALTER TABLE app.delivery_admissions OWNER TO api_migration;

--
-- Name: delivery_outbox; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.delivery_outbox (
    subscription_id uuid NOT NULL,
    trigger_id text NOT NULL,
    event_id text NOT NULL,
    body bytea NOT NULL,
    CONSTRAINT delivery_outbox_body_check CHECK ((octet_length(body) > 0)),
    CONSTRAINT delivery_outbox_event_id_check CHECK ((btrim(event_id) <> ''::text)),
    CONSTRAINT delivery_outbox_trigger_id_check CHECK ((btrim(trigger_id) <> ''::text))
);


ALTER TABLE app.delivery_outbox OWNER TO api_migration;

--
-- Name: delivery_published; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.delivery_published (
    subscription_id uuid NOT NULL
);


ALTER TABLE app.delivery_published OWNER TO api_migration;

--
-- Name: delivery_relay; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.delivery_relay (
    singleton boolean DEFAULT true NOT NULL,
    token bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    CONSTRAINT delivery_relay_singleton_check CHECK (singleton),
    CONSTRAINT delivery_relay_token_check CHECK ((token >= 0))
);


ALTER TABLE app.delivery_relay OWNER TO api_migration;

--
-- Name: delivery_results; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.delivery_results (
    subscription_id uuid NOT NULL,
    workflow_id text NOT NULL,
    attempt_id text NOT NULL,
    outcome text NOT NULL,
    message_id bigint,
    block_reason text,
    binding_version bigint NOT NULL,
    recorded_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT delivery_results_attempt_id_check CHECK ((btrim(attempt_id) <> ''::text)),
    CONSTRAINT delivery_results_binding_version_check CHECK ((binding_version > 0)),
    CONSTRAINT delivery_results_check CHECK ((((outcome = 'succeeded'::text) AND (message_id IS NOT NULL) AND (message_id > 0) AND (block_reason IS NULL)) OR ((outcome = ANY (ARRAY['retryable'::text, 'uncertain'::text])) AND (message_id IS NULL) AND (block_reason IS NULL)) OR ((outcome = 'blocked'::text) AND (message_id IS NULL) AND (block_reason IS NOT NULL) AND (block_reason = ANY (ARRAY['channel_unavailable'::text, 'attempts_exhausted'::text, 'permanent_failure'::text]))))),
    CONSTRAINT delivery_results_outcome_check CHECK ((outcome = ANY (ARRAY['succeeded'::text, 'retryable'::text, 'uncertain'::text, 'blocked'::text]))),
    CONSTRAINT delivery_results_workflow_id_check CHECK ((btrim(workflow_id) <> ''::text))
);


ALTER TABLE app.delivery_results OWNER TO api_migration;

--
-- Name: sessions; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.sessions (
    token_hash bytea NOT NULL,
    user_id uuid NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT sessions_token_hash_check CHECK ((octet_length(token_hash) = 32))
);


ALTER TABLE app.sessions OWNER TO api_migration;

--
-- Name: subscription_relay; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscription_relay (
    singleton boolean DEFAULT true NOT NULL,
    "position" bigint DEFAULT 0 NOT NULL,
    token bigint DEFAULT 0 NOT NULL,
    lease_until timestamp with time zone,
    CONSTRAINT subscription_relay_position_check CHECK (("position" >= 0)),
    CONSTRAINT subscription_relay_singleton_check CHECK (singleton),
    CONSTRAINT subscription_relay_token_check CHECK ((token >= 0))
);


ALTER TABLE app.subscription_relay OWNER TO api_migration;

--
-- Name: subscription_replay_pins; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscription_replay_pins (
    id uuid NOT NULL,
    owner text NOT NULL,
    progress bigint NOT NULL,
    issued bigint NOT NULL,
    phase text NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT subscription_replay_pins_check CHECK ((issued >= progress)),
    CONSTRAINT subscription_replay_pins_owner_check CHECK (((length(owner) >= 1) AND (length(owner) <= 200))),
    CONSTRAINT subscription_replay_pins_phase_check CHECK ((phase = ANY (ARRAY['snapshot'::text, 'replay'::text, 'abandoned'::text]))),
    CONSTRAINT subscription_replay_pins_progress_check CHECK ((progress >= 0))
);


ALTER TABLE app.subscription_replay_pins OWNER TO api_migration;

--
-- Name: subscription_snapshot_requests; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscription_snapshot_requests (
    owner text NOT NULL,
    request_id text NOT NULL,
    ttl_ns bigint NOT NULL,
    snapshot_id uuid NOT NULL,
    CONSTRAINT subscription_snapshot_requests_owner_check CHECK (((length(owner) >= 1) AND (length(owner) <= 200))),
    CONSTRAINT subscription_snapshot_requests_request_id_check CHECK ((((length(request_id) >= 1) AND (length(request_id) <= 128)) AND (request_id !~ '[^A-Za-z0-9_.-]'::text))),
    CONSTRAINT subscription_snapshot_requests_ttl_ns_check CHECK (((ttl_ns >= 1000) AND (ttl_ns <= '86400000000000'::bigint)))
);


ALTER TABLE app.subscription_snapshot_requests OWNER TO api_migration;

--
-- Name: subscription_snapshot_rows; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscription_snapshot_rows (
    snapshot_id uuid NOT NULL,
    id uuid CONSTRAINT subscriptions_id_not_null NOT NULL,
    owner_id uuid CONSTRAINT subscriptions_owner_id_not_null NOT NULL,
    pair text CONSTRAINT subscriptions_pair_not_null NOT NULL,
    threshold numeric CONSTRAINT subscriptions_threshold_not_null NOT NULL,
    direction text CONSTRAINT subscriptions_direction_not_null NOT NULL,
    creation_price numeric CONSTRAINT subscriptions_creation_price_not_null NOT NULL,
    creation_trade_time timestamp with time zone CONSTRAINT subscriptions_creation_trade_time_not_null NOT NULL,
    percent text,
    stale boolean CONSTRAINT subscriptions_stale_not_null NOT NULL,
    stream_unconfirmed boolean CONSTRAINT subscriptions_stream_unconfirmed_not_null NOT NULL,
    gap_detected boolean CONSTRAINT subscriptions_gap_detected_not_null NOT NULL,
    state text CONSTRAINT subscriptions_state_not_null NOT NULL,
    version bigint CONSTRAINT subscriptions_version_not_null NOT NULL,
    activation text CONSTRAINT subscriptions_activation_not_null NOT NULL,
    workflow_id text,
    workflow_version bigint,
    block_reason text,
    blocked_binding_version bigint,
    quota_reserved boolean CONSTRAINT subscriptions_quota_reserved_not_null NOT NULL,
    admission_fence bigint CONSTRAINT subscriptions_admission_fence_not_null NOT NULL,
    current_attempt_id text,
    delivered_attempt_id text,
    delivered_message_id bigint
);


ALTER TABLE app.subscription_snapshot_rows OWNER TO api_migration;

--
-- Name: subscription_snapshots; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscription_snapshots (
    id uuid NOT NULL,
    owner text NOT NULL,
    boundary bigint NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT subscription_snapshots_boundary_check CHECK ((boundary >= 0)),
    CONSTRAINT subscription_snapshots_owner_check CHECK (((length(owner) >= 1) AND (length(owner) <= 200)))
);


ALTER TABLE app.subscription_snapshots OWNER TO api_migration;

--
-- Name: subscriptions; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_id uuid NOT NULL,
    pair text NOT NULL,
    threshold numeric NOT NULL,
    direction text NOT NULL,
    creation_price numeric NOT NULL,
    creation_trade_time timestamp with time zone NOT NULL,
    percent text,
    stale boolean DEFAULT false NOT NULL,
    stream_unconfirmed boolean DEFAULT false NOT NULL,
    gap_detected boolean DEFAULT false NOT NULL,
    state text NOT NULL,
    version bigint NOT NULL,
    activation text NOT NULL,
    workflow_id text,
    workflow_version bigint,
    block_reason text,
    blocked_binding_version bigint,
    quota_reserved boolean DEFAULT false NOT NULL,
    admission_fence bigint DEFAULT 0 NOT NULL,
    current_attempt_id text,
    delivered_attempt_id text,
    delivered_message_id bigint,
    CONSTRAINT subscriptions_activation_check CHECK ((activation = 'latest_price'::text)),
    CONSTRAINT subscriptions_admission_fence_check CHECK ((admission_fence >= 0)),
    CONSTRAINT subscriptions_attempt_valid CHECK (((current_attempt_id IS NULL) OR ((btrim(current_attempt_id) <> ''::text) AND (admission_fence > 0)))),
    CONSTRAINT subscriptions_block_valid CHECK ((((state = 'delivery_blocked'::text) AND (block_reason IS NOT NULL) AND (block_reason = ANY (ARRAY['channel_unavailable'::text, 'attempts_exhausted'::text, 'permanent_failure'::text])) AND (blocked_binding_version IS NOT NULL) AND (blocked_binding_version >= 0)) OR ((state <> 'delivery_blocked'::text) AND (block_reason IS NULL) AND (blocked_binding_version IS NULL)))),
    CONSTRAINT subscriptions_creation_price_check CHECK (((creation_price > (0)::numeric) AND (creation_price < ('1000000000000000000'::bigint)::numeric) AND (scale(creation_price) <= 18))),
    CONSTRAINT subscriptions_creation_trade_time_check CHECK (((creation_trade_time > '0001-01-01 00:00:00+00'::timestamp with time zone) AND (creation_trade_time < '10000-01-01 00:00:00+00'::timestamp with time zone))),
    CONSTRAINT subscriptions_direction_check CHECK ((direction = ANY (ARRAY['up'::text, 'down'::text]))),
    CONSTRAINT subscriptions_pair_check CHECK ((pair ~ '^[A-Z0-9]+$'::text)),
    CONSTRAINT subscriptions_percent_check CHECK (((percent ~ '^[+-]?[0-9]+([.][0-9]{1,18})?$'::text) AND ((percent)::numeric > ('-100'::integer)::numeric) AND ((percent)::numeric <> (0)::numeric) AND ((percent)::numeric < ('1000000000000000000'::bigint)::numeric))),
    CONSTRAINT subscriptions_receipt_valid CHECK ((((delivered_attempt_id IS NULL) AND (delivered_message_id IS NULL)) OR ((state = 'delivered'::text) AND (delivered_attempt_id IS NOT NULL) AND (btrim(delivered_attempt_id) <> ''::text) AND (delivered_message_id IS NOT NULL) AND (delivered_message_id > 0)))),
    CONSTRAINT subscriptions_state_check CHECK ((state = ANY (ARRAY['active'::text, 'pending_delivery'::text, 'sending'::text, 'delivery_blocked'::text, 'delivered'::text, 'cancelled'::text]))),
    CONSTRAINT subscriptions_state_workflow CHECK (((state <> ALL (ARRAY['pending_delivery'::text, 'sending'::text, 'delivered'::text])) OR (workflow_id IS NOT NULL))),
    CONSTRAINT subscriptions_threshold_check CHECK (((threshold >= (0)::numeric) AND (threshold < ('1000000000000000000'::bigint)::numeric) AND (scale(threshold) <= 18))),
    CONSTRAINT subscriptions_version_check CHECK ((version > 0)),
    CONSTRAINT subscriptions_workflow_id_check CHECK ((btrim(workflow_id) <> ''::text)),
    CONSTRAINT subscriptions_workflow_valid CHECK ((((workflow_id IS NULL) AND (workflow_version IS NULL)) OR ((workflow_id IS NOT NULL) AND (workflow_version IS NOT NULL) AND (workflow_version > 0))))
);


ALTER TABLE app.subscriptions OWNER TO api_migration;

--
-- Name: telegram_link_codes; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.telegram_link_codes (
    user_id uuid NOT NULL,
    code_hash bytea NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    CONSTRAINT telegram_link_codes_code_hash_check CHECK ((octet_length(code_hash) = 32))
);


ALTER TABLE app.telegram_link_codes OWNER TO api_migration;

--
-- Name: users; Type: TABLE; Schema: app; Owner: api_migration
--

CREATE TABLE app.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    telegram_chat_id bigint,
    telegram_version bigint DEFAULT 0 NOT NULL,
    active_subscriptions smallint DEFAULT 0 NOT NULL,
    CONSTRAINT users_active_subscriptions_range CHECK (((active_subscriptions >= 0) AND (active_subscriptions <= 15))),
    CONSTRAINT users_email_normalized CHECK (((email <> ''::text) AND (email = lower(email)) AND (email !~ '[[:space:]]'::text))),
    CONSTRAINT users_password_hash_present CHECK ((btrim(password_hash) <> ''::text)),
    CONSTRAINT users_telegram_binding_valid CHECK ((((telegram_chat_id IS NULL) OR (telegram_chat_id > 0)) AND (telegram_version >= 0) AND ((telegram_chat_id IS NULL) OR (telegram_version > 0))))
);


ALTER TABLE app.users OWNER TO api_migration;

--
-- Name: history; Type: TABLE; Schema: migration; Owner: api_migration
--

CREATE TABLE migration.history (
    version bigint NOT NULL,
    name text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT history_version_check CHECK ((version > 0))
);


ALTER TABLE migration.history OWNER TO api_migration;

--
-- Name: api_journal_batches api_journal_batches_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal_batches
    ADD CONSTRAINT api_journal_batches_pkey PRIMARY KEY (transaction_id);


--
-- Name: api_journal_batches api_journal_batches_transaction_end_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal_batches
    ADD CONSTRAINT api_journal_batches_transaction_end_key UNIQUE (transaction_end);


--
-- Name: api_journal_counter api_journal_counter_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal_counter
    ADD CONSTRAINT api_journal_counter_pkey PRIMARY KEY (singleton);


--
-- Name: api_journal api_journal_event_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal
    ADD CONSTRAINT api_journal_event_id_key UNIQUE (event_id);


--
-- Name: api_journal api_journal_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal
    ADD CONSTRAINT api_journal_pkey PRIMARY KEY ("position");


--
-- Name: delivery_admissions delivery_admissions_attempt_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_admissions
    ADD CONSTRAINT delivery_admissions_attempt_id_key UNIQUE (attempt_id);


--
-- Name: delivery_admissions delivery_admissions_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_admissions
    ADD CONSTRAINT delivery_admissions_pkey PRIMARY KEY (subscription_id, request_id);


--
-- Name: delivery_admissions delivery_admissions_subscription_id_fence_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_admissions
    ADD CONSTRAINT delivery_admissions_subscription_id_fence_key UNIQUE (subscription_id, fence);


--
-- Name: delivery_outbox delivery_outbox_event_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_outbox
    ADD CONSTRAINT delivery_outbox_event_id_key UNIQUE (event_id);


--
-- Name: delivery_outbox delivery_outbox_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_outbox
    ADD CONSTRAINT delivery_outbox_pkey PRIMARY KEY (subscription_id);


--
-- Name: delivery_outbox delivery_outbox_trigger_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_outbox
    ADD CONSTRAINT delivery_outbox_trigger_id_key UNIQUE (trigger_id);


--
-- Name: delivery_published delivery_published_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_published
    ADD CONSTRAINT delivery_published_pkey PRIMARY KEY (subscription_id);


--
-- Name: delivery_relay delivery_relay_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_relay
    ADD CONSTRAINT delivery_relay_pkey PRIMARY KEY (singleton);


--
-- Name: delivery_results delivery_results_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_results
    ADD CONSTRAINT delivery_results_pkey PRIMARY KEY (attempt_id, outcome);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (token_hash);


--
-- Name: subscription_relay subscription_relay_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_relay
    ADD CONSTRAINT subscription_relay_pkey PRIMARY KEY (singleton);


--
-- Name: subscription_replay_pins subscription_replay_pins_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_replay_pins
    ADD CONSTRAINT subscription_replay_pins_pkey PRIMARY KEY (id);


--
-- Name: subscription_snapshot_requests subscription_snapshot_requests_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_snapshot_requests
    ADD CONSTRAINT subscription_snapshot_requests_pkey PRIMARY KEY (owner, request_id);


--
-- Name: subscription_snapshot_requests subscription_snapshot_requests_snapshot_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_snapshot_requests
    ADD CONSTRAINT subscription_snapshot_requests_snapshot_id_key UNIQUE (snapshot_id);


--
-- Name: subscription_snapshot_rows subscription_snapshot_rows_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_snapshot_rows
    ADD CONSTRAINT subscription_snapshot_rows_pkey PRIMARY KEY (snapshot_id, id);


--
-- Name: subscription_snapshots subscription_snapshots_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_snapshots
    ADD CONSTRAINT subscription_snapshots_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_workflow_id_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscriptions
    ADD CONSTRAINT subscriptions_workflow_id_key UNIQUE (workflow_id);


--
-- Name: telegram_link_codes telegram_link_codes_code_hash_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.telegram_link_codes
    ADD CONSTRAINT telegram_link_codes_code_hash_key UNIQUE (code_hash);


--
-- Name: telegram_link_codes telegram_link_codes_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.telegram_link_codes
    ADD CONSTRAINT telegram_link_codes_pkey PRIMARY KEY (user_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_telegram_chat_key; Type: CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.users
    ADD CONSTRAINT users_telegram_chat_key UNIQUE (telegram_chat_id);


--
-- Name: history history_pkey; Type: CONSTRAINT; Schema: migration; Owner: api_migration
--

ALTER TABLE ONLY migration.history
    ADD CONSTRAINT history_pkey PRIMARY KEY (version);


--
-- Name: api_journal_transaction; Type: INDEX; Schema: app; Owner: api_migration
--

CREATE INDEX api_journal_transaction ON app.api_journal USING btree (transaction_end, "position");


--
-- Name: delivery_results_subscription; Type: INDEX; Schema: app; Owner: api_migration
--

CREATE INDEX delivery_results_subscription ON app.delivery_results USING btree (subscription_id);


--
-- Name: sessions_user_id_idx; Type: INDEX; Schema: app; Owner: api_migration
--

CREATE INDEX sessions_user_id_idx ON app.sessions USING btree (user_id);


--
-- Name: subscription_replay_pins_expiry; Type: INDEX; Schema: app; Owner: api_migration
--

CREATE INDEX subscription_replay_pins_expiry ON app.subscription_replay_pins USING btree (expires_at);


--
-- Name: subscriptions_owner_id; Type: INDEX; Schema: app; Owner: api_migration
--

CREATE INDEX subscriptions_owner_id ON app.subscriptions USING btree (owner_id, id);


--
-- Name: api_journal api_journal_transaction_end_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.api_journal
    ADD CONSTRAINT api_journal_transaction_end_fkey FOREIGN KEY (transaction_end) REFERENCES app.api_journal_batches(transaction_end);


--
-- Name: delivery_published delivery_published_subscription_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.delivery_published
    ADD CONSTRAINT delivery_published_subscription_id_fkey FOREIGN KEY (subscription_id) REFERENCES app.delivery_outbox(subscription_id);


--
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES app.users(id) ON DELETE CASCADE;


--
-- Name: subscription_replay_pins subscription_replay_pins_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_replay_pins
    ADD CONSTRAINT subscription_replay_pins_id_fkey FOREIGN KEY (id) REFERENCES app.subscription_snapshots(id);


--
-- Name: subscription_snapshot_rows subscription_snapshot_rows_snapshot_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscription_snapshot_rows
    ADD CONSTRAINT subscription_snapshot_rows_snapshot_id_fkey FOREIGN KEY (snapshot_id) REFERENCES app.subscription_snapshots(id);


--
-- Name: subscriptions subscriptions_owner_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.subscriptions
    ADD CONSTRAINT subscriptions_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES app.users(id);


--
-- Name: telegram_link_codes telegram_link_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: app; Owner: api_migration
--

ALTER TABLE ONLY app.telegram_link_codes
    ADD CONSTRAINT telegram_link_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES app.users(id) ON DELETE CASCADE;


--
-- Name: SCHEMA app; Type: ACL; Schema: -; Owner: api_migration
--

GRANT USAGE ON SCHEMA app TO api_runtime;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- Name: FUNCTION reject_unlogged(); Type: ACL; Schema: storage_guard; Owner: postgres
--

REVOKE ALL ON FUNCTION storage_guard.reject_unlogged() FROM PUBLIC;


--
-- Name: TABLE api_journal; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.api_journal TO api_runtime;


--
-- Name: TABLE api_journal_batches; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.api_journal_batches TO api_runtime;


--
-- Name: TABLE api_journal_counter; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT ON TABLE app.api_journal_counter TO api_runtime;


--
-- Name: COLUMN api_journal_counter."position"; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE("position") ON TABLE app.api_journal_counter TO api_runtime;


--
-- Name: TABLE delivery_admissions; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.delivery_admissions TO api_runtime;


--
-- Name: TABLE delivery_outbox; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.delivery_outbox TO api_runtime;


--
-- Name: TABLE delivery_published; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.delivery_published TO api_runtime;


--
-- Name: TABLE delivery_relay; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT ON TABLE app.delivery_relay TO api_runtime;


--
-- Name: COLUMN delivery_relay.token; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(token) ON TABLE app.delivery_relay TO api_runtime;


--
-- Name: COLUMN delivery_relay.lease_until; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(lease_until) ON TABLE app.delivery_relay TO api_runtime;


--
-- Name: TABLE delivery_results; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.delivery_results TO api_runtime;


--
-- Name: TABLE sessions; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.sessions TO api_runtime;


--
-- Name: TABLE subscription_relay; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT ON TABLE app.subscription_relay TO api_runtime;


--
-- Name: COLUMN subscription_relay."position"; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE("position") ON TABLE app.subscription_relay TO api_runtime;


--
-- Name: COLUMN subscription_relay.token; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(token) ON TABLE app.subscription_relay TO api_runtime;


--
-- Name: COLUMN subscription_relay.lease_until; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(lease_until) ON TABLE app.subscription_relay TO api_runtime;


--
-- Name: TABLE subscription_replay_pins; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.subscription_replay_pins TO api_runtime;


--
-- Name: COLUMN subscription_replay_pins.progress; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(progress) ON TABLE app.subscription_replay_pins TO api_runtime;


--
-- Name: COLUMN subscription_replay_pins.issued; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(issued) ON TABLE app.subscription_replay_pins TO api_runtime;


--
-- Name: COLUMN subscription_replay_pins.phase; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(phase) ON TABLE app.subscription_replay_pins TO api_runtime;


--
-- Name: COLUMN subscription_replay_pins.expires_at; Type: ACL; Schema: app; Owner: api_migration
--

GRANT UPDATE(expires_at) ON TABLE app.subscription_replay_pins TO api_runtime;


--
-- Name: TABLE subscription_snapshot_requests; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.subscription_snapshot_requests TO api_runtime;


--
-- Name: TABLE subscription_snapshot_rows; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.subscription_snapshot_rows TO api_runtime;


--
-- Name: TABLE subscription_snapshots; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT ON TABLE app.subscription_snapshots TO api_runtime;


--
-- Name: TABLE subscriptions; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.subscriptions TO api_runtime;


--
-- Name: TABLE telegram_link_codes; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.telegram_link_codes TO api_runtime;


--
-- Name: TABLE users; Type: ACL; Schema: app; Owner: api_migration
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE app.users TO api_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: app; Owner: api_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE api_migration IN SCHEMA app GRANT SELECT,USAGE ON SEQUENCES TO api_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: app; Owner: api_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE api_migration IN SCHEMA app GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO api_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: -; Owner: api_migration
--

ALTER DEFAULT PRIVILEGES FOR ROLE api_migration REVOKE ALL ON FUNCTIONS FROM PUBLIC;


--
-- Name: reject_unlogged; Type: EVENT TRIGGER; Schema: -; Owner: postgres
--

CREATE EVENT TRIGGER reject_unlogged ON ddl_command_end
   EXECUTE FUNCTION storage_guard.reject_unlogged();


ALTER EVENT TRIGGER reject_unlogged OWNER TO postgres;

--
-- PostgreSQL database dump complete
--

\unrestrict obG9AAexgpeo73u1ae1Q8BUTwWaPuC34EWKmGHxyyJUrhMtOigLFqyX34xHLLd6

